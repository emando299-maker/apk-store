# APK Store — Android starter project (v1.1)

متجر تطبيقات عربي RTL بتصميم داكن، مبني باستخدام Kotlin وJetpack Compose، مع قاعدة بيانات SQLite محلية للمحفوظات.

## الوظائف
- واجهة عربية داكنة مع بحث وتصنيفات.
- حفظ التطبيقات وإزالتها من قائمة المحفوظات باستخدام SQLite.
- كتالوج أولي لتطبيقات مفتوحة المصدر مع صفحة تفاصيل لكل تطبيق.
- جلب أحدث إصدار واسم ملف APK من واجهة F-Droid عند الضغط على «تحميل APK».
- تنزيل الملف إلى مجلد Downloads باستخدام Android DownloadManager.
- التحقق من بصمة SHA-256 للملف بعد التنزيل باستخدام البصمة المنشورة في بيانات F-Droid؛ يُحذف الملف إذا لم تتطابق البصمة.
- زر لفتح صفحة التطبيق على F-Droid عند تعذر الوصول إلى بيانات الإصدار.

## المصدر والنطاق
يستخدم المشروع واجهة بيانات F-Droid (`https://f-droid.org/api/v1/packages/{packageName}`) ومستودع APK الرسمي (`https://f-droid.org/repo/`). التطبيق لا يستخرج APK من Google Play ولا يستخدم روابط تنزيل عشوائية. بعض الحزم في الكتالوج قد لا تكون متاحة في F-Droid أو قد تتغير بياناتها؛ في هذه الحالة يفتح التطبيق صفحة المصدر للمراجعة.

## بناء APK
1. ثبّت Android Studio وAndroid SDK Platform 35 وJDK 17.
2. افتح مجلد `apk_store_android` في Android Studio وانتظر مزامنة Gradle.
3. اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. بعد نجاح البناء، يوجد الملف عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

## التقنيات
- Kotlin + Jetpack Compose + Material 3
- SQLiteOpenHelper
- Kotlin Coroutines
- Android DownloadManager
- minSdk 24، targetSdk 35

ملاحظة: ملفات المصدر مرفقة، لكن لم يتم إرفاق APK مبني مسبقًا لأن بيئة العمل الحالية لا تحتوي على Android SDK/Gradle مثبتين.
