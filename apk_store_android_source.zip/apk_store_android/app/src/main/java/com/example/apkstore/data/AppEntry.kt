package com.example.apkstore.data

data class AppEntry(
    val id: String,
    val name: String,
    val developer: String,
    val category: String,
    val description: String,
    val packageName: String,
    val icon: String,
    val size: String = "يتحدد من المصدر"
) {
    val sourceUrl: String get() = "https://f-droid.org/packages/$packageName/"
}

object Catalog {
    // Curated package IDs for open-source Android apps listed by F-Droid.
    val apps = listOf(
        AppEntry("vlc", "VLC", "VideoLAN", "وسائط", "مشغل فيديو وصوت مفتوح المصدر", "org.videolan.vlc", "▶️"),
        AppEntry("telegram", "Telegram", "Telegram FOSS", "تواصل", "تطبيق مراسلة؛ راجع صفحة المصدر للتفاصيل", "org.telegram.messenger", "✈️"),
        AppEntry("newpipe", "NewPipe", "NewPipe Team", "وسائط", "مشغل وسائط مفتوح المصدر", "org.schabi.newpipe", "🎬"),
        AppEntry("fdroid", "F-Droid", "F-Droid Community", "متجر", "كتالوج تطبيقات أندرويد مفتوحة المصدر", "org.fdroid.fdroid", "📦"),
        AppEntry("aegis", "Aegis Authenticator", "Beem Development", "أمان", "تطبيق رموز تحقق ثنائية", "com.beemdevelopment.aegis", "🔐"),
        AppEntry("fossify-gallery", "Fossify Gallery", "Fossify", "صور", "معرض صور مفتوح المصدر", "org.fossify.gallery", "🖼️"),
        AppEntry("fossify-filemanager", "Fossify File Manager", "Fossify", "أدوات", "إدارة الملفات على الجهاز", "org.fossify.filemanager", "📁"),
        AppEntry("antennapod", "AntennaPod", "AntennaPod Team", "وسائط", "إدارة وتشغيل البودكاست", "de.danoeh.antennapod", "🎧"),
        AppEntry("organicmaps", "Organic Maps", "Organic Maps", "خرائط", "خرائط وملاحة مع دعم الاستخدام دون اتصال", "app.organicmaps", "🗺️"),
        AppEntry("bitwarden", "Bitwarden", "Bitwarden Inc.", "أمان", "مدير كلمات مرور مفتوح المصدر", "com.x8bit.bitwarden", "🔑")
    )
}
