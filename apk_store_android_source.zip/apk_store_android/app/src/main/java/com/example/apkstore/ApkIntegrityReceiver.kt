package com.example.apkstore

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.security.MessageDigest

/** Checks downloaded APK bytes against the SHA-256 published by F-Droid's package API. */
class ApkIntegrityReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != DownloadManager.ACTION_DOWNLOAD_COMPLETE) return
        val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
        if (id < 0L) return
        val prefs = context.getSharedPreferences("apk_integrity", Context.MODE_PRIVATE)
        val expected = prefs.getString("sha_$id", null) ?: return
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return
        cursor.use {
            if (!it.moveToFirst()) return
            val statusCol = it.getColumnIndex(DownloadManager.COLUMN_STATUS)
            val uriCol = it.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
            if (statusCol < 0 || uriCol < 0) return
            if (it.getInt(statusCol) != DownloadManager.STATUS_SUCCESSFUL) {
                prefs.edit().remove("sha_$id").apply()
                return
            }
            val localUri = it.getString(uriCol) ?: run {
                manager.remove(id); prefs.edit().remove("sha_$id").apply(); return
            }
            val actual = try {
                val digest = MessageDigest.getInstance("SHA-256")
                context.contentResolver.openInputStream(Uri.parse(localUri))?.use { stream ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val read = stream.read(buffer)
                        if (read < 0) break
                        digest.update(buffer, 0, read)
                    }
                } ?: throw IllegalStateException("Unable to read downloaded file")
                digest.digest().joinToString("") { b -> "%02x".format(b) }
            } catch (_: Exception) {
                ""
            }
            prefs.edit().remove("sha_$id").apply()
            if (!actual.equals(expected, ignoreCase = true)) {
                manager.remove(id)
                Toast.makeText(context, "تم حذف الملف: فشل التحقق من بصمة SHA-256", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "اكتمل التنزيل وتم التحقق من بصمة الملف", Toast.LENGTH_LONG).show()
            }
        }
    }
}
