package com.example.apkstore.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

 data class ApkRelease(
    val versionName: String,
    val versionCode: Long,
    val apkName: String,
    val sha256: String,
    val size: Long
) {
    val downloadUrl: String get() = "https://f-droid.org/repo/$apkName"
}

object FdroidClient {
    suspend fun latestRelease(packageName: String): ApkRelease? = withContext(Dispatchers.IO) {
        val connection = (URL("https://f-droid.org/api/v1/packages/$packageName").openConnection() as HttpURLConnection).apply {
            connectTimeout = 12000
            readTimeout = 12000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "APKStore-Android/1.1")
        }
        try {
            if (connection.responseCode !in 200..299) return@withContext null
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            val releases = json.optJSONArray("packages") ?: json.optJSONArray("versions") ?: JSONArray()
            var best: JSONObject? = null
            for (i in 0 until releases.length()) {
                val item = releases.optJSONObject(i) ?: continue
                if (best == null || item.optLong("versionCode") > best!!.optLong("versionCode")) best = item
            }
            val item = best ?: return@withContext null
            val apkName = item.optString("apkName", "")
            val hash = item.optString("hash", "")
            if (apkName.isBlank() || hash.length != 64 || !apkName.startsWith(packageName + "_")) return@withContext null
            ApkRelease(
                versionName = item.optString("versionName", "غير معروف"),
                versionCode = item.optLong("versionCode"),
                apkName = apkName,
                sha256 = hash.lowercase(),
                size = item.optLong("size")
            )
        } finally {
            connection.disconnect()
        }
    }
}
