package com.example.apkstore.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class FavoritesDb(context: Context) : SQLiteOpenHelper(context, "apk_store.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE favorites (app_id TEXT PRIMARY KEY NOT NULL, saved_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun allIds(): Set<String> {
        val result = mutableSetOf<String>()
        readableDatabase.rawQuery("SELECT app_id FROM favorites ORDER BY saved_at DESC", null).use { c ->
            while (c.moveToNext()) result += c.getString(0)
        }
        return result
    }
    fun toggle(id: String): Boolean {
        val db = writableDatabase
        val exists = db.rawQuery("SELECT 1 FROM favorites WHERE app_id=?", arrayOf(id)).use { it.moveToFirst() }
        if (exists) db.delete("favorites", "app_id=?", arrayOf(id))
        else db.insertWithOnConflict("favorites", null, ContentValues().apply {
            put("app_id", id); put("saved_at", System.currentTimeMillis())
        }, SQLiteDatabase.CONFLICT_REPLACE)
        return !exists
    }
}
