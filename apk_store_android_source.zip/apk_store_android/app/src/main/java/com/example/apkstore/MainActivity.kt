package com.example.apkstore

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.apkstore.data.AppEntry
import com.example.apkstore.data.Catalog
import com.example.apkstore.data.FavoritesDb
import com.example.apkstore.data.FdroidClient
import kotlinx.coroutines.launch
import java.util.Locale

private val Bg = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val Green = Color(0xFF19D18B)
private val Muted = Color(0xFF9BB0C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = FavoritesDb(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel)) {
                StoreScreen(db = db)
            }
        }
    }
}

@Composable
private fun StoreScreen(db: FavoritesDb) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var query by remember { mutableStateOf("") }
        var selectedTab by remember { mutableIntStateOf(0) }
        var selectedCategory by remember { mutableStateOf("الكل") }
        var savedIds by remember { mutableStateOf(db.allIds()) }
        var downloadingIds by remember { mutableStateOf(setOf<String>()) }
        var statusMessage by remember { mutableStateOf<String?>(null) }
        var detailsApp by remember { mutableStateOf<AppEntry?>(null) }
        val categories = listOf("الكل", "تواصل", "وسائط", "أمان", "أدوات", "صور", "خرائط", "متجر")
        val visibleApps = Catalog.apps.filter { app ->
            (app.name.contains(query, true) || app.developer.contains(query, true) || app.category.contains(query, true)) &&
                (selectedTab == 0 || app.id in savedIds) &&
                (selectedCategory == "الكل" || app.category == selectedCategory)
        }

        Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("APK STORE", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("متجر التطبيقات", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(48.dp).background(Panel, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                    Text("APK", color = Green, fontWeight = FontWeight.Black)
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, contentDescription = "بحث", tint = Muted)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("ابحث عن تطبيق أو مطوّر...", color = Muted)
                    BasicTextField(value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth().background(Color(0xFF0D3B35), RoundedCornerShape(18.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("تطبيقات مفتوحة المصدر", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("التنزيل من مستودع F-Droid الرسمي", color = Color(0xFFB7ECDD), fontSize = 12.sp)
                }
                Text("✓", color = Green, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = selectedTab == 0, onClick = { selectedTab = 0 }, label = { Text("كل التطبيقات") })
                FilterChip(selected = selectedTab == 1, onClick = { selectedTab = 1 }, label = { Text("المحفوظة (${savedIds.size})") })
            }
            Spacer(Modifier.height(6.dp))
            androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(categories) { category ->
                    FilterChip(selected = selectedCategory == category, onClick = { selectedCategory = category }, label = { Text(category) })
                }
            }
            Text(if (selectedTab == 0) "تطبيقات مقترحة" else "قائمة المحفوظات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
            statusMessage?.let { Text(it, color = Green, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp)) }
            if (visibleApps.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("مفيش تطبيقات مطابقة لبحثك", color = Muted) }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(visibleApps, key = { it.id }) { app ->
                        AppCard(app = app, isSaved = app.id in savedIds, isDownloading = app.id in downloadingIds,
                            onSave = { db.toggle(app.id); savedIds = db.allIds() },
                            onDetails = { detailsApp = app },
                            onDownload = {
                                if (app.id !in downloadingIds) {
                                    downloadingIds = downloadingIds + app.id
                                    statusMessage = "جاري جلب أحدث إصدار من المصدر الرسمي..."
                                    scope.launch {
                                        try {
                                            val release = FdroidClient.latestRelease(app.packageName)
                                            if (release == null) {
                                                statusMessage = "تعذر العثور على إصدار متاح عبر واجهة F-Droid لهذا التطبيق. يمكنك فتح صفحة المصدر."
                                                openUrl(context, app.sourceUrl)
                                            } else {
                                                startApkDownload(context, release.downloadUrl, release.apkName, release.sha256)
                                                statusMessage = "بدأ تنزيل ${app.name} (${release.versionName}) من F-Droid."
                                            }
                                        } catch (_: Exception) {
                                            statusMessage = "تعذر الاتصال بالمصدر. تحقق من الإنترنت أو افتح صفحة التطبيق الرسمية."
                                            openUrl(context, app.sourceUrl)
                                        } finally {
                                            downloadingIds = downloadingIds - app.id
                                        }
                                    }
                                }
                            })
                    }
                }
            }
        }
        detailsApp?.let { app ->
            AlertDialog(
                onDismissRequest = { detailsApp = null },
                containerColor = Panel,
                title = { Text(app.name, color = Color.White, fontWeight = FontWeight.Bold) },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(app.description, color = Muted)
                    Text("المطوّر: ${app.developer}", color = Color.White)
                    Text("المصدر: F-Droid الرسمي", color = Green)
                    Text("معرّف الحزمة: ${app.packageName}", color = Muted, fontSize = 12.sp)
                    Text("سيتم جلب الإصدار ورابط APK وقت التنزيل لتجنب الروابط القديمة.", color = Muted, fontSize = 12.sp)
                } },
                confirmButton = { TextButton(onClick = { openUrl(context, app.sourceUrl); detailsApp = null }) { Text("صفحة المصدر") } },
                dismissButton = { TextButton(onClick = { detailsApp = null }) { Text("إغلاق") } }
            )
        }
    }
}

@Composable
private fun AppCard(app: AppEntry, isSaved: Boolean, isDownloading: Boolean, onSave: () -> Unit, onDetails: () -> Unit, onDownload: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).background(Color(0xFF1A3046), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
            Text(app.icon, fontSize = 24.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(app.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(app.developer, color = Muted, fontSize = 11.sp)
            Text("${app.category} • F-Droid", color = Green, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onDownload, enabled = !isDownloading, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 3.dp), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color(0xFF04251B))) {
                    if (isDownloading) { CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = Color(0xFF04251B)); Spacer(Modifier.width(5.dp)) }
                    Text(if (isDownloading) "جاري التجهيز" else "تحميل APK", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onDetails, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)) { Text("التفاصيل", fontSize = 11.sp) }
            }
        }
        IconButton(onClick = onSave) {
            Icon(if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "حفظ التطبيق", tint = if (isSaved) Green else Muted)
        }
    }
}

private fun startApkDownload(context: Context, url: String, fileName: String, expectedSha256: String) {
    val uri = Uri.parse(url)
    require(uri.scheme == "https" && uri.host == "f-droid.org" && uri.path?.startsWith("/repo/") == true) {
        "Only official F-Droid repository APK links are allowed"
    }
    val request = DownloadManager.Request(uri)
        .setTitle(fileName)
        .setDescription("تنزيل APK من مستودع F-Droid الرسمي")
        .setMimeType("application/vnd.android.package-archive")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val downloadId = manager.enqueue(request)
    context.getSharedPreferences("apk_integrity", Context.MODE_PRIVATE).edit()
        .putString("sha_$downloadId", expectedSha256).apply()
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (_: Exception) { Toast.makeText(context, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() }
}
